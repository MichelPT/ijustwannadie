module.exports = {
    HOST: 'localhost',
    USER: 'root',
    DATABASE: 'compute_engine_app',
    PASSWORD: '',
    PORT: '3306'
  };